setwd("/Volumes/Data1/PROJECTS/circRNAs_final/circRNA_Landscape/DHG_DATA/CompleteDataset/REVISION/")
library(DeconRNASeq)
rm(list=ls())
load("DATA_TABLES/data_DS1.rda")
load("DATA_TABLES/data_DS2.rda")
nsig=read.csv("Annotation_GeneLists/Lake2018_NeuronalSigs.csv")
asig=read.csv("Annotation_GeneLists/Lake2018_AstrocyticSigs.csv")
rownames(nsig)=nsig[,1]
rownames(asig)=asig[,1]

nsig=nsig[match(rownames(asig), rownames(nsig)),]

CBsig=cbind(asig$cb, nsig$cb); colnames(CBsig)=c("Astro", "Neur")
CTXsig=cbind(asig$ctx, nsig$cb); colnames(CBsig)=colnames(CTXsig)=c("Astro", "Neur")
rownames(CBsig)=rownames(CTXsig)=rownames(nsig)
###############DS1

data1=data_DS1$geneData_DS1$rpkm_filter
samples1=data_DS1$sampleInfo_DS1
infocols=c(1,2)
d1_CB = DeconRNASeq(data1[,-infocols], as.data.frame(CBsig))$out.all
d1_CTX = DeconRNASeq(data1[,-infocols], as.data.frame(CTXsig))$out.all
rownames(d1_CB)=rownames(d1_CTX)=colnames(data1[,-infocols])


colors=rep("midnightblue", ncol(data1[,-infocols])); colors[grep("verm", colnames(data1[,-infocols]))]="indianred"
plot(d1_CTX[,1], d1_CB[,1], xlim=c(0.3,0.8), ylim=c(0.3,0.7), pch=20, col=colors)
d1_CTX=as.data.frame(d1_CTX)
d1_CB=as.data.frame(d1_CB)
d1_CTX[,3]="refCTX"; d1_CB[,3]="refCB"
d1_CTX[,4]="bulkCTX"; d1_CTX[grep("verm", colnames(data1[,-infocols])),4]="bulkCB"
d1_CB[,4]="bulkCTX"; d1_CB[grep("verm", colnames(data1[,-infocols])),4]="bulkCB"
plotdata=as.data.frame(rbind(d1_CTX, d1_CB))
plotdata$Categ=paste(plotdata[,4], plotdata[,3], sep="_")

ggplot(plotdata, aes(x=Categ, y=Neur)) + geom_boxplot()

cor(d1_CTX[grep("verm", colnames(data1[,-infocols])),1], d1_CB[grep("verm", colnames(data1[,-infocols])),1])
cor(d1_CTX[-grep("verm", colnames(data1[,-infocols])),1], d1_CB[-grep("verm", colnames(data1[,-infocols])),1])
