##  Initial SETUP & Sample prep
## ----------------------------------------------------------------------------------
rm(list = ls())

project.dir <- "/Volumes/Data1/PROJECTS/circRNAs_final/circRNA_Landscape/DHG_DATA/"
complete.dir <- paste0(project.dir, "CompleteDataset/")
complete.data_table.dir <- paste0(complete.dir, "DATA_TABLES/")
output.dir <- paste0(complete.data_table.dir, "autoBLAST/Input/Flanking_Introns/")

##  Sample Info
ds1.sample.info <- read.table(file=paste0(complete.data_table.dir, "/sampleInfo_DS1.csv"), header = TRUE, stringsAsFactor = FALSE, sep = ",")
dim(ds1.sample.info)
ds2.sample.info <- read.table(file=paste0(complete.data_table.dir, "/sampleInfo_DS2.csv"), header = TRUE, stringsAsFactor = FALSE, sep = ",")
dim(ds2.sample.info)

##  Load Data
load(paste0(complete.data_table.dir, "/data_DS1.rda"))
load(paste0(complete.data_table.dir, "/data_DS2.rda"))


##  ANNOTATION prep
## ----------------------------------------------------------------------------------

annot.dir <- "/Users/rna/REFERENCE/HUMAN/Ensembl_GRCh37_hg19/ANNOTATION/GTF/GTF_to_BED/"
intron.bed <- read.table(file = paste0(annot.dir, "introns.bed"), header = FALSE, stringsAsFactors = FALSE, sep = "\t")
bedInfoCols <- c("Chr", "Start", "End", "AnnotationID", "EnsID", "strand") 
colnames(intron.bed) <- bedInfoCols

# Calculate length
intron.bed$length <- intron.bed$End - intron.bed$Start

# Remove duplicates
dupIntron <- which(duplicated(intron.bed$AnnotationID))
intron.bed <- intron.bed[-dupIntron,]


##  ANALYSIS
## ----------------------------------------------------------------------------------

setwd(project.dir)

## Extracting and Processing circRNA that are expressed in Brain samples in both DS1 and DS2 dataset
ds1.circ.circCpm_filter.df <- data_DS1$circData_DS1$circCpm_filter[,1:15]
dim(ds1.circ.circCpm_filter.df)
# [1] 14386   159
ds2.circ.circCpm_filter.df <- data_DS2$circData_DS2$circCpm_filter[,1:15]
dim(ds2.circ.circCpm_filter.df)
# [1] 9440   68
head(ds1.circ.circCpm_filter.df,2)
# Coordinate  Chr     Start       End                       Id           EnsID Symbol       Annot Strand      startEnsID        endEnsID
# chr1_10032076_10041228_+     chr1_10032076_10041228_+ chr1  10032076  10041228   chr1_10032076_10041228 ENSG00000173614 NMNAT1 exonJ_exonJ      + ENSG00000173614 ENSG00000173614
# chr1_100335956_100343384_+ chr1_100335956_100343384_+ chr1 100335956 100343384 chr1_100335956_100343384 ENSG00000162688    AGL exonJ_exonJ      + ENSG00000162688 ENSG00000162688
# startSymbol endSymbol startAnnot endAnnot
# chr1_10032076_10041228_+        NMNAT1    NMNAT1      exonJ    exonJ
# chr1_100335956_100343384_+         AGL       AGL      exonJ    exonJ

table(ds1.circ.circCpm_filter.df$Annot)
# chimeric_exonJ_exonJ    chimeric_exonJ_genic chimeric_exonJ_intronic            exonic_exonJ            exonJ_exonic             exonJ_exonJ        exonJ_intergenic 
# 56                       4                       7                     254                     238                   12786                      55 
# exonJ_intronic            genic_exonic             genic_genic        genic_intergenic          genic_intronic       intergenic_exonic        intergenic_exonJ 
# 236                     112                      56                       1                      73                      24                      51 
# intergenic_genic   intergenic_intergenic     intergenic_intronic          intronic_exonJ 
# 8                     165                      14                     246

table(ds2.circ.circCpm_filter.df$Annot)
# chimeric_exonJ_exonJ    chimeric_exonJ_genic chimeric_exonJ_intronic            exonic_exonJ            exonJ_exonic             exonJ_exonJ        exonJ_intergenic 
# 1                       1                       1                     151                     152                    8741                      28 
# exonJ_intronic            genic_exonic             genic_genic          genic_intronic       intergenic_exonic        intergenic_exonJ        intergenic_genic 
# 93                      58                      13                      30                       2                      19                       4 
# intergenic_intergenic     intergenic_intronic          intronic_exonJ 
# 48                       3                      95 


##  Only working on exonJ_exonJ circRNA
ds1.circ.circCpm_filter.exonJ_exonJ.df <- ds1.circ.circCpm_filter.df[ds1.circ.circCpm_filter.df$Annot == "exonJ_exonJ",]
dim(ds1.circ.circCpm_filter.exonJ_exonJ.df)
# [1] 12786    15

ds2.circ.circCpm_filter.exonJ_exonJ.df <- ds2.circ.circCpm_filter.df[ds2.circ.circCpm_filter.df$Annot == "exonJ_exonJ",]
dim(ds2.circ.circCpm_filter.exonJ_exonJ.df)
# [1] 8741   15

circBedCol <- c("Chr", "Start", "End", "Coordinate", "Strand")
ds1.circ.exonJ_exonJ.bed <- ds1.circ.circCpm_filter.exonJ_exonJ.df[,circBedCol]
ds1.circ.exonJ_exonJ.bed$Chr <- gsub(pattern = "chr", replacement = "", ds1.circ.exonJ_exonJ.bed$Chr)

ds2.circ.exonJ_exonJ.bed <- ds2.circ.circCpm_filter.exonJ_exonJ.df[,circBedCol]
ds2.circ.exonJ_exonJ.bed$Chr <- gsub(pattern = "chr", replacement = "", ds2.circ.exonJ_exonJ.bed$Chr)

dup <- which(duplicated(ds1.circ.exonJ_exonJ.bed$Coordinate))
if(length(dup) > 0) ds1.circ.exonJ_exonJ.bed <- ds1.circ.exonJ_exonJ.bed[-dup,]
dim(ds1.circ.exonJ_exonJ.bed)
# [1] 12786     5

dup <- which(duplicated(ds2.circ.exonJ_exonJ.bed$Coordinate))
if(length(dup) > 0) ds2.circ.exonJ_exonJ.bed <- ds2.circ.exonJ_exonJ.bed[-dup,]
dim(ds2.circ.exonJ_exonJ.bed)
# [1] 8741    5

ds1.circ.exonJ_exonJ_wt_chr.bed <- ds1.circ.exonJ_exonJ.bed
ds1.circ.exonJ_exonJ_w_chr.bed <- ds1.circ.exonJ_exonJ.bed
ds1.circ.exonJ_exonJ_w_chr.bed$Chr <- paste0("chr", ds1.circ.exonJ_exonJ_w_chr.bed$Chr)

ds2.circ.exonJ_exonJ_wt_chr.bed <- ds2.circ.exonJ_exonJ.bed
ds2.circ.exonJ_exonJ_w_chr.bed <- ds2.circ.exonJ_exonJ.bed
ds2.circ.exonJ_exonJ_w_chr.bed$Chr <- paste0("chr", ds2.circ.exonJ_exonJ_w_chr.bed$Chr)

ds1.circ.exonJ_exonJ_w_chr_plus.bed <- ds1.circ.exonJ_exonJ_w_chr.bed[ds1.circ.exonJ_exonJ_w_chr.bed$Strand == "+",]
ds1.circ.exonJ_exonJ_w_chr_minus.bed <- ds1.circ.exonJ_exonJ_w_chr.bed[ds1.circ.exonJ_exonJ_w_chr.bed$Strand == "-",]

ds2.circ.exonJ_exonJ_w_chr_plus.bed <- ds2.circ.exonJ_exonJ_w_chr.bed[ds2.circ.exonJ_exonJ_w_chr.bed$Strand == "+",]
ds2.circ.exonJ_exonJ_w_chr_minus.bed <- ds2.circ.exonJ_exonJ_w_chr.bed[ds2.circ.exonJ_exonJ_w_chr.bed$Strand == "-",]

##  Write exonJ_exonJ circRNA BED file
write.table(ds1.circ.exonJ_exonJ_w_chr.bed, file = paste0(output.dir, "ds1_circ_exonJ_exonJ.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")
write.table(ds2.circ.exonJ_exonJ_w_chr.bed, file = paste0(output.dir, "ds2_circ_exonJ_exonJ.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")

write.table(ds1.circ.exonJ_exonJ_wt_chr.bed, file = paste0(output.dir, "ds1_circ_exonJ_exonJ_wt_chr.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")
write.table(ds2.circ.exonJ_exonJ_wt_chr.bed, file = paste0(output.dir, "ds2_circ_exonJ_exonJ_wt_chr.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")

write.table(ds1.circ.exonJ_exonJ_w_chr_plus.bed, file = paste0(output.dir, "ds1_circ_exonJ_exonJ_plus_strand.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")
write.table(ds1.circ.exonJ_exonJ_w_chr_minus.bed, file = paste0(output.dir, "ds1_circ_exonJ_exonJ_minus_strand.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")

write.table(ds2.circ.exonJ_exonJ_w_chr_plus.bed, file = paste0(output.dir, "ds2_circ_exonJ_exonJ_plus_strand.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")
write.table(ds2.circ.exonJ_exonJ_w_chr_minus.bed, file = paste0(output.dir, "ds2_circ_exonJ_exonJ_minus_strand.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")

##  Write intron BED file (with "chr")
intron_w_chr.bed <- intron.bed
intron_w_chr.bed$Chr <- paste0("chr", intron_w_chr.bed$Chr)
intron_w_chr.bed <- intron_w_chr.bed[, c("Chr", "Start", "End", "AnnotationID", "strand")]

write.table(intron_w_chr.bed, file = paste0(output.dir,"introns.bed"), quote = FALSE, row.names = FALSE, col.names=FALSE, sep = "\t")



