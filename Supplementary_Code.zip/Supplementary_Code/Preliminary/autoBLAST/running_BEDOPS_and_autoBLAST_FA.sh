#!/bin/bash

##	Define genome folder
genome="/Volumes/MacintoshHD_RNA/Users/rna/REFERENCE/HUMAN/Ensembl_GRCh37_hg19/genome/genome.fa"

##	Define working folder
FI="/Volumes/Data1/PROJECTS/circRNAs_final/circRNA_Landscape/DHG_DATA/CompleteDataset/DATA_TABLES/autoBLAST/Input/Flanking_Introns"

##	All circRNA data
circDS1BED="/Volumes/Data1/PROJECTS/circRNAs_final/circRNA_Landscape/DHG_DATA/CompleteDataset/DATA_TABLES/autoBLAST/Input/Flanking_Introns/ds1_circ_exonJ_exonJ_wt_chr.bed"
circDS2BED="/Volumes/Data1/PROJECTS/circRNAs_final/circRNA_Landscape/DHG_DATA/CompleteDataset/DATA_TABLES/autoBLAST/Input/Flanking_Introns/ds2_circ_exonJ_exonJ_wt_chr.bed"

##	Define autoBLAST folder
AB="/Users/rna/PROGRAMS/autoBLAST"

##	Run autoBLAST for +/- 200 bp window
cp $circDS1BED /Users/rna/PROGRAMS/autoBLAST/
cp $circDS2BED /Users/rna/PROGRAMS/autoBLAST/

#	Run autoBLAST on DS1
./master_script.sh 1 ds1_circ_plus_200_minus_200 ds1_circ_exonJ_exonJ_wt_chr.bed $genome 200 -200 -200 200

#	Run autoBLAST on DS2
./master_script.sh 1 ds2_circ_plus_200_minus_200 ds2_circ_exonJ_exonJ_wt_chr.bed $genome 200 -200 -200 200


##	Preprocess circBED files for whole intron autoBLAST
cd ${FI}

##	Sort BED file by chr 
##	(Note: BED file chr/first column needs to have "chr" as part of chromosome)
##	Sort + & minus strans separately
sortBed -i ds1_circ_exonJ_exonJ.bed > ds1_circ_exonJ_exonJ_sorted.bed

sortBed -i ds2_circ_exonJ_exonJ.bed > ds2_circ_exonJ_exonJ_sorted.bed

##	Sort introns BED file
sortBed -i introns.bed > introns_sorted.bed 

##	Sorting intron BED file by chr 

##	Using BEDOPS program available @ https://bedops.readthedocs.io/en/latest/
closest-features --no-overlaps --delim '\t' ds1_circ_exonJ_exonJ_sorted.bed introns_sorted.bed > ds1_circ_intron.bed

closest-features --no-overlaps --delim '\t' ds2_circ_exonJ_exonJ_sorted.bed introns_sorted.bed > ds2_circ_intron.bed

##	Separate upstream and downstream introns
cat ds1_circ_intron.bed | awk 'BEGIN{OFS="\t"}{print $6, $7, $8, $9, $10;}' > ds1_upstream_introns.bed 

cat ds1_circ_intron.bed | awk 'BEGIN{OFS="\t"}{print $11, $12, $13, $14, $15;}' > ds1_downstream_introns.bed

cat ds2_circ_intron.bed | awk 'BEGIN{OFS="\t"}{print $6, $7, $8, $9, $10;}' > ds2_upstream_introns.bed

cat ds2_circ_intron.bed | awk 'BEGIN{OFS="\t"}{print $11, $12, $13, $14, $15;}' > ds2_downstream_introns.bed 

##	Remove "chr" from Chromosome column
awk 'BEGIN { OFS="\t" } { $1 = substr($1, 4); print }' ds1_upstream_introns.bed > ds1_upstream_introns_wt_chr.bed

awk 'BEGIN { OFS="\t" } { $1 = substr($1, 4); print }' ds1_downstream_introns.bed > ds1_downstream_introns_wt_chr.bed

awk 'BEGIN { OFS="\t" } { $1 = substr($1, 4); print }' ds2_upstream_introns.bed > ds2_upstream_introns_wt_chr.bed

awk 'BEGIN { OFS="\t" } { $1 = substr($1, 4); print }' ds2_downstream_introns.bed > ds2_downstream_introns_wt_chr.bed

awk 'BEGIN { OFS="\t" } { $1 = substr($1, 4); print }' ds1_circ_exonJ_exonJ_sorted.bed > ds1_circ_exonJ_exonJ_sorted_wt_chr.bed

awk 'BEGIN { OFS="\t" } { $1 = substr($1, 4); print }' ds2_circ_exonJ_exonJ_sorted.bed > ds2_circ_exonJ_exonJ_sorted_wt_chr.bed

##	Prepare upstream and downstream intron file to be compatible with autoBLAST
##	For DS1
cp ds1_circ_exonJ_exonJ_sorted_wt_chr.bed ${AB}/ds1_circ_exonJ_exonJ_sorted_wt_chr.bed
cp ds1_upstream_introns_wt_chr.bed ${AB}/upstream_introns.bed
cp ds1_downstream_introns_wt_chr.bed ${AB}/downstream_introns.bed

##	Change folder to autoBLAST
cd ${AB}

##	Run autoBLAST for whole intron (upstream & downstream)
##	Output will be written in /Users/rna/PROGRAMS/autoBLAST/Output_circ_DS_exonJ_exonJ_whole/
master_script.sh 0 ds1_circ_exonJ_exonJ_whole ds1_circ_exonJ_exonJ_sorted_wt_chr.bed $genome

cd ${FI}

##	For DS2
cp ds2_circ_exonJ_exonJ_sorted_wt_chr.bed ${AB}/ds2_circ_exonJ_exonJ_sorted_wt_chr.bed
cp ds2_upstream_introns_wt_chr.bed ${AB}/upstream_introns.bed
cp ds2_downstream_introns_wt_chr.bed ${AB}/downstream_introns.bed

##	Change folder to autoBLAST
cd ${AB}

##	Run autoBLAST for whole intron (upstream & downstream)
##	Output will be written in /Users/rna/PROGRAMS/autoBLAST/Output_circ_DS_exonJ_exonJ_whole/
master_script.sh 0 ds2_circ_exonJ_exonJ_whole ds2_circ_exonJ_exonJ_sorted_wt_chr.bed $genome

